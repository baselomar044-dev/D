# Structural QTO Engine

This is the Python AI engine responsible for performing High-Precision Geometric Quantity Takeoff (QTO) on structural CAD drawings (DXF).

## Features
- **Geometric Tracing**: Direct measurement of vector Polylines/Lines.
- **Layers & Blocks**: Exact extraction of predefined structural layers (`BEAM`, `FOOTING`, `COLUMN`, `SLAB`).
- **Substructure Algorithms**: Excavation, Backfilling, Neck Columns, Bitumen, and Solid Block Work.
- **Superstructure Algorithms**: Slabs and Floor Columns based on accurate area measurements.

## Usage
1. Install dependencies:
   `pip install -r requirements.txt`
2. Run the engine:
   `python qto_engine.py [path_to_dxf_file]`
3. Output will be generated as a JSON string detailing all structural QTO values.
