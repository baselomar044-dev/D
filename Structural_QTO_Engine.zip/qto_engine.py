import ezdxf
import math
import json
from enum import Enum
from typing import Dict, List, Tuple

class QTOLayer(Enum):
    FOOTING = ["FOU", "FOOTING", "F-S"]
    COLUMN = ["COL", "COLUMN", "COLUMNS", "C-RFT"]
    BEAM = ["BEAM", "BEAMS", "C-BEAMS", "S-BEAM", "GB", "GROUND BEAM", "TIE BEAM"]
    SLAB = ["0 SLAB", "SLAB", "S-SLAB"]

class StructuralQTOEngine:
    def __init__(self, dxf_path: str, params: Dict[str, float] = None):
        """
        Initialize the QTO engine with DXF file and project-specific parameters.
        """
        self.dxf_path = dxf_path
        self.doc = ezdxf.readfile(dxf_path)
        self.msp = self.doc.modelspace()
        
        # Default project parameters if none provided
        self.params = params or {
            "exc_depth": 1.75,
            "gf_level": 0.90,
            "gf_height": 4.30,
            "f1_height": 4.10,
            "slab_thickness": 0.22,
            "pcc_thickness": 0.10,
            "footing_avg_depth": 0.60,
            "working_space": 0.50
        }
        
        # Extracted Data
        self.labels = []
        self.footings = [] # {area, center}
        self.tie_beams = {"TB1,2": 0.0, "TB3": 0.0, "TB4": 0.0, "STB": 0.0, "Unclassified": 0.0}
        self.slabs = [] # {area, is_main_floor}
        self.columns_area = 0.0
        self.columns_count = 0
        
    def _match_layer(self, layer_name: str, enum_type: QTOLayer) -> bool:
        ln = layer_name.upper()
        return any(x in ln for x in enum_type.value)

    def extract_labels(self):
        """Extracts TEXT and MTEXT entities to associate with structural elements."""
        for entity in self.msp.query('TEXT MTEXT'):
            text = entity.plain_text().strip().upper() if entity.dxftype() == 'MTEXT' else entity.dxf.text.strip().upper()
            if "TB" in text or "STB" in text or "GB" in text:
                ins = entity.dxf.insert
                self.labels.append({"text": text, "x": ins.x, "y": ins.y})

    def parse_geometry(self):
        """
        Parses the DXF modelspace and traces geometry for Footings, Beams, Columns, and Slabs.
        Focuses on the Main Plan (X < 0) to avoid detail/legend distortions.
        """
        print("Parsing DXF Geometry...")
        for entity in self.msp.query('LWPOLYLINE'):
            layer = entity.dxf.layer
            
            # Check if it's in the Main Plan (X < 0)
            pts = list(entity.vertices())
            if not pts or not any(p[0] < 0 for p in pts):
                continue
                
            if self._match_layer(layer, QTOLayer.FOOTING):
                if entity.is_closed:
                    self._process_footing(entity)
                    
            elif self._match_layer(layer, QTOLayer.COLUMN):
                if entity.is_closed:
                    self._process_column(entity)
                    
            elif self._match_layer(layer, QTOLayer.BEAM):
                self._process_beam(entity)
                
            elif self._match_layer(layer, QTOLayer.SLAB):
                if getattr(entity, 'is_closed', False) or (pts[0] == pts[-1] if pts else False):
                    self._process_slab(entity)

    def _process_footing(self, polyline):
        vertices = list(polyline.vertices())
        area = self._polygon_area(vertices)
        if area > 0.5: # Filter noise
            self.footings.append(area)

    def _process_column(self, polyline):
        vertices = list(polyline.vertices())
        area = self._polygon_area(vertices)
        if 0.05 < area < 2.0: # Standard column area range limits
            self.columns_area += area
            self.columns_count += 1

    def _process_beam(self, polyline):
        vertices = list(polyline.vertices())
        if len(vertices) < 2: return
        
        # Calculate functional segment length
        length = 0.0
        for i in range(len(vertices)-1):
            dx = vertices[i+1][0] - vertices[i][0]
            dy = vertices[i+1][1] - vertices[i][1]
            length += math.sqrt(dx*dx + dy*dy)
            
        # Geometric Label Mapping (15m radius)
        mid_x = (vertices[0][0] + vertices[-1][0]) / 2.0
        mid_y = (vertices[0][1] + vertices[-1][1]) / 2.0
        
        min_dist = float('inf')
        best_label = "Unclassified"
        
        for lbl in self.labels:
            dist = math.sqrt((lbl['x'] - mid_x)**2 + (lbl['y'] - mid_y)**2)
            if dist < min_dist:
                min_dist = dist
                best_label = lbl['text']
                
        if min_dist < 15.0:
            if "TB1" in best_label or "TB2" in best_label: k = "TB1,2"
            elif "TB3" in best_label: k = "TB3"
            elif "TB4" in best_label: k = "TB4"
            elif "STB" in best_label: k = "STB"
            else: k = "Unclassified"
        else:
            k = "Unclassified"
            
        self.tie_beams[k] += length

    def _process_slab(self, polyline):
        vertices = list(polyline.vertices())
        area = self._polygon_area(vertices)
        if area > 10.0: # Slabs are large
            self.slabs.append(area)

    def _polygon_area(self, vertices):
        area = 0.0
        n = len(vertices)
        for i in range(n):
            j = (i + 1) % n
            area += vertices[i][0] * vertices[j][1]
            area -= vertices[j][0] * vertices[i][1]
        return abs(area) / 2.0

    def calculate_qto(self) -> dict:
        """Runs the algorithms to produce the final QTO JSON."""
        p = self.params
        
        # 1. Base geometric aggregates
        total_footings_area = sum(self.footings)
        total_tb_length = sum(v for k,v in self.tie_beams.items() if k != "Unclassified")
        
        # 2. Substructure
        # Excavation: Footing area + working space * depth
        total_exc_area = sum((math.sqrt(a) + 2*p["working_space"])**2 for a in self.footings)
        excavation_vol = total_exc_area * p["exc_depth"]
        
        # Concrete
        rc_footing_vol = total_footings_area * p["footing_avg_depth"]
        nc_height = p["exc_depth"] - p["pcc_thickness"] - p["footing_avg_depth"]
        if nc_height < 0: nc_height = 0
        nc_vol = self.columns_area * nc_height
        tb_vol = total_tb_length * 0.20 * 0.50 # Avg 20x50 cross-section
        pcc_vol = total_exc_area * p["pcc_thickness"]
        
        # Backfilling
        backfill_vol = excavation_vol - (rc_footing_vol + nc_vol + tb_vol + pcc_vol)
        
        # Sold Block & Bitumen
        solid_block_area = total_tb_length * 0.60 * p["gf_level"] # Approx 60% external TB
        bitumen_area = (total_footings_area * 2) + (self.columns_area * 10) + (total_tb_length * 1.0) # Heuristic surface area
        
        # 3. Superstructure
        slabs_sorted = sorted(self.slabs, reverse=True)
        gf_slab_area = slabs_sorted[0] if len(slabs_sorted) > 0 else 0
        f1_slab_area = slabs_sorted[1] if len(slabs_sorted) > 1 else gf_slab_area
        
        gf_slab_vol = gf_slab_area * p["slab_thickness"]
        f1_slab_vol = f1_slab_area * p["slab_thickness"]
        
        gf_col_vol = self.columns_area * p["gf_height"]
        f1_col_vol = self.columns_area * p["f1_height"]

        qto_results = {
            "Substructure": {
                "Excavation_m3": round(excavation_vol, 2),
                "Backfilling_m3": round(backfill_vol, 2),
                "Neck_Columns_m3": round(nc_vol, 2),
                "Bitumen_Area_m2": round(bitumen_area, 2),
                "Solid_Block_m2": round(solid_block_area, 2),
                "Footings_RC_m3": round(rc_footing_vol, 2),
            },
            "Superstructure": {
                "GF_Slab_m3": round(gf_slab_vol, 2),
                "First_Floor_Slab_m3": round(f1_slab_vol, 2),
                "GF_Columns_m3": round(gf_col_vol, 2),
                "First_Floor_Columns_m3": round(f1_col_vol, 2),
            },
            "Tie_Beams_Geometric_m": {k: round(v, 2) for k, v in self.tie_beams.items()}
        }
        return qto_results

    def run(self):
        self.extract_labels()
        self.parse_geometry()
        return self.calculate_qto()

if __name__ == "__main__":
    import sys
    dxf = sys.argv[1] if len(sys.argv) > 1 else "drawing.dxf"
    # Example specific params supplied by user
    params = {
        "exc_depth": 1.75,
        "gf_level": 0.90,
        "gf_height": 4.30,
        "f1_height": 4.10,
        "slab_thickness": 0.22,
        "pcc_thickness": 0.10,
        "footing_avg_depth": 0.60,
        "working_space": 0.50
    }
    
    try:
        engine = StructuralQTOEngine(dxf, params)
        res = engine.run()
        print(json.dumps(res, indent=4))
    except Exception as e:
        print(f"Error executing Python Engine: {e}")
