# Master QTO Engine (Structural + Architectural)

This is the unified Python AI engine responsible for performing High-Precision Geometric Quantity Takeoff (QTO) on combined architectural and structural drawing files (DXF).

## Features
- **Structural Module**: Concrete Volumes, Footings, Columns, Excavations, Tie Beams.
- **Architectural Module**: Smart Door Extraction (Bounding Box Sizing) and Masonry Intelligence (Double-Line Correction/Centerline Extraction).
- **Universal Accuracy**: Uses mathematically guaranteed geometric tracing, making it independent of specific layer naming conventions.

## Usage
1. Install dependencies:
   `pip install -r requirements.txt`
2. Run the engine:
   `python master_qto_engine.py [path_to_dxf_file]`
3. Output will be generated as a JSON string detailing all structural and architectural QTO values simultaneously.
