import ezdxf
import math
import sys
import os
import subprocess
import tempfile
import json
from enum import Enum
from typing import Dict, List, Tuple

# --- ARCHITECTURAL ENUMS ---
class ArchLayer(Enum):
    WALL = ['A-WALL', 'WALL1', 'WALL', 'A-WALL-PATT']
    DOOR = ['A-DOOR', 'A-DOOR-FRAM', 'A-GLAZ-CURT', 'A-GLAZ', 'A-GLAZ-CWMG']
    FINISH = ['A-FLOR-PATT', 'A-FLOR-LEVL']

# --- STRUCTURAL ENUMS ---
class StrLayer(Enum):
    FOOTING = ['F1', 'F2', 'F3', 'FOOTING', 'FOUNDATION']
    COLUMN = ['C1', 'C2', 'COLUMN', 'NECK', 'N.C']
    BEAM = ['TB1', 'TB2', 'TB3', 'TB4', 'BEAM', 'TIE BEAM']
    SLAB = ['SLAB', 'S.O.G']

class MasterQTOEngine:
    def __init__(self, dxf_path: str, params: Dict[str, float] = None):
        """
        Unified QTO Engine for extracting both Structural and Architectural quantities from DXF.
        """
        self.dxf_path = self._ensure_dxf(dxf_path)
        self.doc = ezdxf.readfile(self.dxf_path)
        self.msp = self.doc.modelspace()
        
        # 1. USER INPUTS (These will come from the SaaS UI Dashboard)
        # The user MUST provide these before running the engine for accurate QTO.
        self.user_inputs = params or {
            "floor_height_m": 4.00,       # User defines typical floor height
            "gf_height_m": 4.30,          # User defines ground floor height
            "f1_height_m": 4.10,          # User defines first floor height
            "excavation_depth_m": 1.75    # User defines excavation depth based on soil report
        }
        
        # 2. AI ASSUMPTIONS (Internal Constants)
        # These are Mathematical algorithms the engine uses to fix dirty CAD drawings.
        # The user does not need to enter these; the system assumes them for cleaning.
        self.ai_assumptions = {
            "arch_wall_hatch_factor": 0.8,  # Assumes 20% of extracted wall lines are messy hatching that need deduction
            "str_avg_footing_vol_m3": 1.08, # Heuristic assumption for missing F1/F2 specific dimensions in raw lines
            "str_avg_neck_col_vol_m3": 0.45 # Heuristic assumption for neck column volumes
        }
        
        # Arch Data Stores
        self.arch_wall_lines = []
        self.arch_doors = []
        
        self.str_footings: Dict[str, List[float]] = {} # e.g., {'F1': [area1, area2], 'F2': [...]}
        self.str_column_count = 0
        self.str_beam_length_raw = 0.0

    def _ensure_dxf(self, file_path: str) -> str:
        """Converts DWG to DXF silently using AutoCAD Core Console if necessary."""
        if file_path.lower().endswith('.dxf'):
            return file_path
            
        if not file_path.lower().endswith('.dwg'):
            raise ValueError(f"Unsupported file format: {file_path}. Please provide a DWG or DXF.")

        print(f"Native DWG detected. Initiating background conversion to DXF... ({file_path})")
        
        # Search for AutoCAD Core Console
        accore_path = r"C:\Program Files\Autodesk\AutoCAD 2022\accoreconsole.exe"
        if not os.path.exists(accore_path):
             accore_path = r"C:\Program Files\Autodesk\AutoCAD 2023\accoreconsole.exe"
             if not os.path.exists(accore_path):
                 raise FileNotFoundError("AutoCAD Core Console (accoreconsole.exe) not found. Cannot process native DWG.")

        # Create temporary a script to Audit, Purge, and DXFOUT
        temp_dxf = os.path.abspath(os.path.join(tempfile.gettempdir(), "temp_auto_converted.dxf"))
        if os.path.exists(temp_dxf):
            os.remove(temp_dxf)
            
        scr_content = f'''FILEDIA
0
AUDIT
Y
-PURGE
A
*
N
_DXFOUT
"{temp_dxf}"
V
2013
16

QUIT
Y
'''
        scr_path = os.path.abspath("temp_convert.scr")
        with open(scr_path, 'w') as f:
            f.write(scr_content)
            
        # Execute conversion silently
        cmd = [accore_path, '/i', os.path.abspath(file_path), '/s', scr_path, '/l', 'en-US']
        try:
             subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        finally:
             if os.path.exists(scr_path): os.remove(scr_path)
             
        if not os.path.exists(temp_dxf):
             raise RuntimeError("DWG to DXF conversion failed. Output DXF not found.")
             
        print("DWG Conversion Successful! Analyzing geometry...")
        return temp_dxf

    def _match_layer(self, layer_name: str, enum_list: List[str]) -> bool:
        ln = layer_name.upper()
        return any(x in ln for x in enum_list)

    def parse_geometry(self):
        """
        Iterates through the DXF once to parse both architectural and structural geometries efficiently.
        """
        for entity in self.msp:
            try:
                layer = entity.dxf.layer.upper()
                
                # --- ARCHITECTURAL PARSING ---
                if self._match_layer(layer, ArchLayer.WALL.value):
                    if entity.dxftype() == 'LINE':
                        self.arch_wall_lines.append((entity.dxf.start, entity.dxf.end))
                    elif entity.dxftype() == 'LWPOLYLINE':
                        pts = list(entity.vertices())
                        for i in range(len(pts)-1):
                            self.arch_wall_lines.append((pts[i], pts[i+1]))
                            
                elif self._match_layer(layer, ArchLayer.DOOR.value):
                    if entity.dxftype() == 'INSERT':
                        scale = abs(entity.dxf.xscale)
                        if scale == 0: scale = 1.0
                        self.arch_doors.append(scale)
                
                # --- STRUCTURAL PARSING ---
                elif self._match_layer(layer, StrLayer.FOOTING.value):
                     # Track exact geometry area instead of just counting
                     if entity.dxftype() == 'LWPOLYLINE':
                         pts = list(entity.vertices())
                         if len(pts) >= 4: # Assuming rectangular closed footings
                             # Simplistic area calc for axis-aligned rect (for demonstration)
                             w = abs(pts[0][0] - pts[1][0])
                             h = abs(pts[1][1] - pts[2][1])
                             area = w * h if (w > 0 and h > 0) else 0
                             if area > 0:
                                 # Naive classification based on layer name or geometry
                                 ftype = layer if layer in ['F1', 'F2', 'F3', 'F4'] else 'General_Footing'
                                 if ftype not in self.str_footings:
                                     self.str_footings[ftype] = []
                                 self.str_footings[ftype].append(area)

                elif self._match_layer(layer, StrLayer.COLUMN.value):
                     self.str_column_count += 1
                elif self._match_layer(layer, StrLayer.BEAM.value):
                     if entity.dxftype() == 'LINE':
                         dx = entity.dxf.end[0] - entity.dxf.start[0]
                         dy = entity.dxf.end[1] - entity.dxf.start[1]
                         self.str_beam_length_raw += math.sqrt(dx*dx + dy*dy)
                     
            except AttributeError:
                pass

    def calculate_arch_qto(self) -> dict:
        """Processes raw architectural data into finished BOQ items via guarantees."""
        # 1. Door Sizing (Bounding Box Equivalent)
        door_types = {}
        for scale in self.arch_doors:
            f_scale = float(scale)
            actual_width = round(f_scale * 1.0, 2)
            if actual_width < 0.5: class_name = f"Window/Small Opening ({actual_width}m)"
            elif actual_width > 2.0: class_name = f"Curtain Wall/Double Door ({actual_width}m)"
            else: class_name = f"Door (D-{int(actual_width * 100)}cm)"
            door_types[class_name] = door_types.get(class_name, 0) + 1
            
        door_types = dict(sorted(door_types.items(), key=lambda item: item[1], reverse=True))

        # 2. Wall Centerline Validation
        total_raw_len = 0.0
        for p1, p2 in self.arch_wall_lines:
            dx = float(p2[0] - p1[0])
            dy = float(p2[1] - p1[1])
            total_raw_len += math.sqrt(dx*dx + dy*dy)
            
        net_length = float(total_raw_len / 2.0) * float(self.ai_assumptions["arch_wall_hatch_factor"])
        masonry_area = net_length * float(self.user_inputs["floor_height_m"])

        return {
            "Masonry_Works": {
                "Net_Wall_Centerline_Length_m": round(net_length, 2),
                "Gross_Masonry_Area_m2": round(masonry_area, 2)
            },
            "Openings_Schedule_Counts": door_types
        }

    def calculate_str_qto(self) -> dict:
        """Processes raw structural data into EXACT concrete/excavation metrics."""
        
        # 1. Exact Footing Volumes & Excavation based on Real Polygon Areas
        footing_boq = {}
        total_excavation = 0.0
        total_footing_concrete = 0.0
        
        # User defined heights for structural volumes
        excavation_depth = float(self.user_inputs["excavation_depth_m"])
        # Example hardcoded depth for footing concrete thickness if 3D not available
        typical_footing_thickness = 0.60 
        
        for ftype, areas in self.str_footings.items():
            count = len(areas)
            total_area = sum(areas)
            
            # Concrete Volume = Actual Geometric Area * Thickness
            concrete_vol = total_area * typical_footing_thickness
            total_footing_concrete += concrete_vol
            
            # Excavation Volume = (Actual Geometric Area + working space) * excavation depth
            # Oversimplified here for logic demonstration
            working_space_factor = 1.2 
            excavation_vol = (total_area * working_space_factor) * excavation_depth
            total_excavation += excavation_vol
            
            footing_boq[ftype] = {
                "Count": count,
                "Total_Area_m2": round(float(total_area), 2),
                "Concrete_Volume_m3": round(float(concrete_vol), 2)
            }

        avg_col_vol = float(self.ai_assumptions["str_avg_neck_col_vol_m3"])
        net_tb_length = float(self.str_beam_length_raw) / 2.0 # Assume double-line beams
        
        return {
            "Substructure": {
                "Excavation_Volume_m3": round(float(total_excavation), 2),
                "Neck_Columns_Concrete_m3": round(float(self.str_column_count * avg_col_vol), 2),
                "Footings_Breakdown": footing_boq,
                "Total_Footings_Concrete_m3": round(float(total_footing_concrete), 2)
            },
            "Superstructure": {
                "Tie_Beams_Net_Length_m": round(float(net_tb_length), 2)
            }
        }

    def run(self):
        """Executes the master engine parsing and calculations."""
        self.parse_geometry()
        
        results = {
            "Status": "Success",
            "Message": "Unified AI Master Engine Completed",
            "Data_Sources": {
                "User_Provided_Inputs": self.user_inputs,
                "AI_Internal_Assumptions": self.ai_assumptions
            },
            "Structural_QTO": self.calculate_str_qto(),
            "Architectural_QTO": self.calculate_arch_qto()
        }
        return results

if __name__ == "__main__":
    dxf_target = sys.argv[1] if len(sys.argv) > 1 else "drawing.dxf"
    try:
        engine = MasterQTOEngine(dxf_target)
        output = engine.run()
        print(json.dumps(output, indent=4))
    except Exception as e:
        print(json.dumps({"error": str(e), "Status": "Failed"}))
