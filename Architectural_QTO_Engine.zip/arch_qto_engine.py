import ezdxf
import math
import json
from enum import Enum
from typing import Dict, List

class ArchLayer(Enum):
    WALL = ['A-WALL', 'WALL1', 'WALL', 'A-WALL-PATT']
    DOOR = ['A-DOOR', 'A-DOOR-FRAM', 'A-GLAZ-CURT', 'A-GLAZ', 'A-GLAZ-CWMG']
    # Finishes logic to be added in future iterations based on room boundary extraction
    FINISH = ['A-FLOR-PATT', 'A-FLOR-LEVL']

class ArchitecturalQTOEngine:
    def __init__(self, dxf_path: str, params: Dict[str, float] = None):
        """
        Initialize the Architectural QTO engine with DXF file and project-specific parameters.
        """
        self.dxf_path = dxf_path
        self.doc = ezdxf.readfile(dxf_path)
        self.msp = self.doc.modelspace()
        
        # Default project parameters
        self.params = params or {
            "floor_height": 4.00, # 4 meters typical floor height
            "wall_thickness_hatch_factor": 0.8 # factor to remove hatching noise
        }
        
        # Extracted Data
        self.wall_lines = []
        self.doors = []
        
    def _match_layer(self, layer_name: str, enum_type: ArchLayer) -> bool:
        ln = layer_name.upper()
        return any(x in ln for x in enum_type.value)

    def parse_geometry(self):
        """
        Parses the DXF modelspace and traces geometry for Walls and Openings.
        """
        for entity in self.msp:
            try:
                layer = entity.dxf.layer.upper()
                
                if self._match_layer(layer, ArchLayer.WALL):
                    if entity.dxftype() == 'LINE':
                        self.wall_lines.append((entity.dxf.start, entity.dxf.end))
                    elif entity.dxftype() == 'LWPOLYLINE':
                        pts = list(entity.vertices())
                        for i in range(len(pts)-1):
                            self.wall_lines.append((pts[i], pts[i+1]))
                            
                elif self._match_layer(layer, ArchLayer.DOOR):
                    if entity.dxftype() == 'INSERT':
                        scale = abs(entity.dxf.xscale)
                        self.doors.append(scale)
            except AttributeError:
                pass

    def calculate_qto(self) -> dict:
        """Runs the algorithms to produce the architectural QTO JSON."""
        # 1. Door Sizing (Bounding Box Equivalent)
        door_types = {}
        base_width_m = 1.0 # The generic '1000' block is ~1m wide. We multiply by scale.
        
        for scale in self.doors:
            actual_width = round(scale * base_width_m, 2)
            
            # Classification Logic
            if actual_width < 0.5: 
                class_name = f"Window/Small Opening ({actual_width}m)"
            elif actual_width > 2.0: 
                class_name = f"Curtain Wall/Double Door ({actual_width}m)"
            else: 
                class_name = f"Door (D-{int(actual_width * 100)}cm)"
                
            door_types[class_name] = door_types.get(class_name, 0) + 1
            
        # Sort doors by count
        door_types = dict(sorted(door_types.items(), key=lambda item: item[1], reverse=True))

        # 2. Wall Centerline Calculation
        # For a 60MB DXF, testing every line against every other line (O(N^2)) is too slow for SaaS.
        # We use a mathematical heuristic: sum of all line lengths / 2 (for double lines) 
        # and multiplied by a hatch reduction factor.
        total_raw_len = 0.0
        for p1, p2 in self.wall_lines:
            dx = p2[0] - p1[0]
            dy = p2[1] - p1[1]
            total_raw_len += math.sqrt(dx*dx + dy*dy)
            
        net_length = (total_raw_len / 2.0) * self.params["wall_thickness_hatch_factor"]
        masonry_area = net_length * self.params["floor_height"]

        qto_results = {
            "Masonry_Works": {
                "Net_Wall_Centerline_Length_m": round(net_length, 2),
                "Gross_Masonry_Area_m2": round(masonry_area, 2),
                "Assumed_Floor_Height_m": self.params["floor_height"]
            },
            "Openings_Schedule_Counts": door_types
        }
        
        return qto_results

    def run(self):
        self.parse_geometry()
        return self.calculate_qto()

if __name__ == "__main__":
    import sys
    dxf = sys.argv[1] if len(sys.argv) > 1 else "drawing.dxf"
    # Execute
    try:
        engine = ArchitecturalQTOEngine(dxf)
        res = engine.run()
        print(json.dumps(res, indent=4))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
