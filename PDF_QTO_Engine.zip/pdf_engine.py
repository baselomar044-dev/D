import fitz  # PyMuPDF
import sys
import json
import logging
from typing import Dict, List, Any
from shapely.geometry import Point, LineString, Polygon
from shapely.ops import polygonize, unary_union
from scipy.spatial import KDTree

# Set up logging for the PDF Engine
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger("PDF_QTO_ENGINE")

class PDFQTOEngine:
    """
    Phase 4: Vector PDF QTO Engine.
    Extracts raw vector paths and text from PDFs, applying 'Brutal Perfection'
    spatial binding (Shapely/KDTree) since PDFs lack native CAD layers.
    """
    def __init__(self, pdf_path: str, calibration_scale: float = 1.0):
        self.pdf_path = pdf_path
        # Calibration Scale: Multiplier to convert PDF Points (1/72 inch) to Meters.
        # This MUST be calculated by the user providing a known dimension on the PDF.
        # Defaulting to 1.0 means output will be in raw PDF Points.
        self.scale = calibration_scale 
        
        self.raw_lines: List[LineString] = []
        self.raw_texts: List[Dict[str, Any]] = []
        
        # User Defined Heights (Same logic as CAD engine for QS standardization)
        self.params = {
            "excavation_depth_m": 1.75,
            "typical_footing_thickness_m": 0.60
        }

    def extract_raw_vectors(self):
        """
        Scans the PDF and extracts all vector line segments and text boxes,
        ignoring raster images.
        """
        logger.info(f"Opening PDF: {self.pdf_path}")
        try:
            doc = fitz.open(self.pdf_path)
            
            for page_num, page in enumerate(doc):
                logger.info(f"Scanning Page {page_num + 1}...")
                
                # 1. Extract Vector Paths (Lines, Curves, Rects)
                paths = page.get_drawings()
                logger.info(f"Found {len(paths)} drawing paths on page {page_num + 1}.")
                
                for p in paths:
                    for item in p["items"]:
                        # item[0] is the drawing command type (e.g., 'l' for line, 're' for rect)
                        if item[0] == "l":
                            # item[1] is start Point, item[2] is end Point
                            p1 = (item[1].x * self.scale, item[1].y * self.scale)
                            p2 = (item[2].x * self.scale, item[2].y * self.scale)
                            self.raw_lines.append(LineString([p1, p2]))
                            
                        # Future expansion: handle 're' (rectangles), 'c' (curves) here
                        
                # 2. Extract Text Blocks
                words = page.get_text("words")
                logger.info(f"Found {len(words)} text words on page {page_num + 1}.")
                
                for w in words:
                    # w format: (x0, y0, x1, y1, text, block_n, line_n, word_n)
                    text_val = w[4].strip().upper()
                    if text_val: # Only store non-empty strings
                        # We use the top-left corner (x0, y0) as the anchor point for spatial search
                        pos = Point(w[0] * self.scale, w[1] * self.scale)
                        self.raw_texts.append({"text": text_val, "point": pos})
                        
            logger.info(f"Extraction Complete: {len(self.raw_lines)} lines, {len(self.raw_texts)} texts.")
            
        except Exception as e:
            logger.error(f"Failed to read PDF: {e}")
            raise

    def run_spatial_binding(self) -> Dict[str, Any]:
        """
        The core AI of PDF Extraction: 
        1. Welds broken lines. 
        2. Polygonizes closed areas. 
        3. Binds floating text to the nearest polygon.
        """
        if not self.raw_lines:
            return {"status": "Failed", "message": "No lines found to analyze."}
            
        logger.info("Starting Gap Welding (Buffer 5mm)...")
        # 1. Welds lines with a 5mm tolerance to force closure
        welded = unary_union([l.buffer(0.005) for l in self.raw_lines])
        
        logger.info("Extracting Polygons...")
        polygons = list(polygonize(welded.boundary))
        logger.info(f"Generated {len(polygons)} closed polygons.")
        
        # 2. Spatial Binding using KDTree
        qto_results = {}
        if polygons and self.raw_texts:
            logger.info("Binding text to geometry using KDTree...")
            tree = KDTree([(p.centroid.x, p.centroid.y) for p in polygons])
            
            for txt_obj in self.raw_texts:
                label = txt_obj["text"]
                # Only bind structural tags for now
                if label.startswith('F') or label.startswith('C') or label == 'TB':
                    dist, idx = tree.query((txt_obj["point"].x, txt_obj["point"].y), distance_upper_bound=1.0)
                    if dist != float('inf'):
                        poly = polygons[idx]
                        if label not in qto_results:
                            qto_results[label] = {"count": 0, "total_area_m2": 0.0}
                        qto_results[label]["count"] += 1
                        qto_results[label]["total_area_m2"] += poly.area

        return qto_results

    def generate_boq(self, spatial_results: Dict[str, Any]) -> Dict[str, Any]:
        """Converts spatial areas into standard QS BOQ items."""
        boq = {}
        for tag, data in spatial_results.items():
            if tag.startswith('F'):
                 vol = data["total_area_m2"] * self.params["typical_footing_thickness_m"]
                 boq[tag] = {
                     "Count": data["count"],
                     "Area_m2": round(data["total_area_m2"], 2),
                     "Concrete_Volume_m3": round(vol, 2)
                 }
        return boq

    def run(self) -> Dict[str, Any]:
        """Executes the extraction and calculation pipeline."""
        self.extract_raw_vectors()
        spatial_results = self.run_spatial_binding()
        final_boq = self.generate_boq(spatial_results)
        
        return {
            "status": "Success",
            "message": "BRUTAL PERFECTION PDF Engine Completed",
            "file": self.pdf_path,
            "Substructure_QTO": final_boq
        }

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python pdf_engine.py <path_to_pdf_file>")
        sys.exit(1)
        
    pdf_target = sys.argv[1]
    engine = PDFQTOEngine(pdf_target)
    
    try:
        result = engine.run()
        print(json.dumps(result, indent=4))
    except Exception as e:
        print(json.dumps({"error": str(e), "status": "Failed"}, indent=4))
